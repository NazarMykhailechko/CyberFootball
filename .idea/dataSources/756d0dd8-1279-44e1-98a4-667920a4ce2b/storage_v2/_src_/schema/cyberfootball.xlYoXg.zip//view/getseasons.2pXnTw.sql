create definer = root@localhost view getseasons as
select distinct `cyberfootball`.`datacyber`.`season` AS `season`
from `cyberfootball`.`datacyber`;

