create definer = root@localhost view getteamsall as
select `cyberfootball`.`datacyber`.`season`            AS `season`,
       max(`cyberfootball`.`datacyber`.`nickhomelong`) AS `Nick`,
       `cyberfootball`.`datacyber`.`nickhome`          AS `Nick9`
from `cyberfootball`.`datacyber`
where (str_to_date(left(`cyberfootball`.`datacyber`.`dates`, 8),
                   '%d.%m.%Y') between cast('2020-04-06' as date) and cast('2020-04-06' as date))
group by `cyberfootball`.`datacyber`.`season`, `cyberfootball`.`datacyber`.`nickhome`
union
select `cyberfootball`.`datacyber`.`season`            AS `season`,
       max(`cyberfootball`.`datacyber`.`nickawaylong`) AS `Nick`,
       `cyberfootball`.`datacyber`.`nickaway`          AS `Nick9`
from `cyberfootball`.`datacyber`
where (str_to_date(left(`cyberfootball`.`datacyber`.`dates`, 8),
                   '%d.%m.%Y') between cast('2020-04-06' as date) and cast('2020-04-06' as date))
group by `cyberfootball`.`datacyber`.`season`, `cyberfootball`.`datacyber`.`nickaway`;

