create definer = root@localhost view dbsize as
select `tables`.`TABLE_SCHEMA`                                                   AS `datacyber`,
       ((sum((`tables`.`DATA_LENGTH` + `tables`.`INDEX_LENGTH`)) / 1024) / 1024) AS `database size in MB`
from `information_schema`.`TABLES`
group by `tables`.`TABLE_SCHEMA`;

